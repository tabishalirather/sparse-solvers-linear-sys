/*
 *
 *  \author Jens-Peter Zemke
 *  \author Sabine Le Borne
*/

#include "itsolver.h"

csr *csr_permute(csr *A, const int *pinv, const int *q)
{
  csr *B = csr_alloc(A->nr, A->nc, A->nz);
  int ne = 0;
  int i;

  /* ******************************************************************** */
  /*                                                                      */
  /*     TODO --- Problem 1                                               */
  /*                                                                      */
  /* ******************************************************************** */  
  
  return B;
}

csr *csr_perm(csr *A, perm_t *row_perm, perm_t *col_perm)
{
  return csr_permute(A, row_perm->idx_inv, col_perm->idx);
}

csr *csr_perm_symm(csr *A, perm_t *perm)
{
  return csr_perm(A, perm, perm);
}

