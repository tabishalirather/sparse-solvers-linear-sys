/*! \file
 *  \brief Amount of fillin generated with ILU(p) for different values of p.
 *
 *  \author Michael Wende
 *  \author Jens-Peter Zemke
 *  \author Sabine Le Borne
 */

#include "itsolver.h"

int main(int argc, char **argv)
{
  int d = 3;
  if (argc > 1)
  {
    d = atoi(argv[1]);
  }
  int n = 10;
  if (argc > 2)
  {
    n = atoi(argv[2]);
  }
  int pmax = 20;
  if (argc > 3)
  {
    pmax = atoi(argv[3]);
  }
  printf("n = %d, d = %d, pmax = %d\n", n, d, pmax);
  int nd = pow(n - 1, d);

  /* Test matrix. */
  csr *A = csr_laplace(n, d);

  /* Permutation. */
  perm_t *perms[4];
  double *nnz_rel[4];

  perms[0] = perm_identity(nd);
  perms[1] = perm_cmk(A, -1);
  perms[2] = perm_nested_dissection(A);
  perms[3] =  perm_independent_set(A);

  /* ************************************ */
  /*                                      */
  /*         TODO --- Problem 1a          */
  /* Apply permutation and store the      */
  /* relative number of nonzero entries.  */
  /*                                      */
  /* ************************************ */

  for (int i = 0; i < 4; i++)
  {

    /* Reserve storage for the relative number of nonzero entries */
    nnz_rel[i] = (double *) malloc((pmax+1) * sizeof(double));
    
    /* Apply a permutation */
    // csr *B = ...

    for (int p = 0; p <= pmax; p++)
    {
      /* ILU(p). */
      // csr *C = ...

      /* Compute and store relative number of non-zeros. */
      // nnz_rel[i][p] = ...

      /* Free memory.*/
      // csr_free(C);
    }
  }

  /* Free memory.*/
  csr_free(A);
  for (int i = 0; i < 4; i++)
    perm_delete(perms[i]);

  /* Output File */
  FILE *OUT;
  // File is overwritten (and created if not existing)
  OUT = fopen("testprog_09_ilup_fillin.txt", "w");

  /* Write data to the output file */ 
  for (int p = 0; p <= pmax; p++)
  {

    /* Print p */
    fprintf(OUT, "%2d", p);

    /* Print relative number of non-zero entries for each permutation */
    for (int i = 0; i < 4; i++)
      fprintf(OUT, " %1.6e", nnz_rel[i][p]);
    fprintf(OUT, "\n");
  }

  /* Close output file */
  fclose(OUT);

  /* Free memory*/
  for (int i = 0; i < 4; i++)
    free(nnz_rel[i]);

  return 0;
}
